Chào Admin! Có người một khách hàng liên hệ từ website nè: <hr>
<p>Họ tên khách hàng {{$hoten}}</p>
<p>Nội dung khách liên hệ : <br> 
    {!! nl2br($noidung)!!}
<p></p>