@extends('layout')

@section('title') Trang download @endsection

@section('noidungchinh')

<h3 class="alert alert-info p-3 text-center">

Đây là trang download, chỉ hiện cho các user đã đăng nhập

</h3>

@endsection