<?php $__env->startSection('title'); ?> Chinh tài khoản <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form class="mt-5" id="frm" method="post" action="<?php echo e(route('user.update', $user->id )); ?>" class="m-auto w-10 border border-primary">

    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <h4 class="m-0 bg-warning p-2 fs-5"> CHỈNH TÀI KHOẢN</h4>

    <div class="mb-3 row px-2">

        <div class='col-6'> Tên tài khoản

            <input name="name" type="text" value="<?php echo e($user->name); ?>" class="form-control shadow-none border-primary">

        </div>

        <div class='col-6'> Email
            <input name="email" type="email" value="<?php echo e($user->email); ?>" class="form-control shadow-none border-primary">
        </div>

    </div>

    <div class="mb-3 row px-2">

        <div class='col-6'> Mật khẩu

            <input name="password" type="password" value="<?php echo e($user->password); ?>" class="form-control shadow-none border-primary">
        </div>

        <div class='col-6'> Số điện thoại

            <input name="number" type="text" value="<?php echo e($user->number); ?>" class="form-control shadow-none border-primary">
        </div>

    </div>

    <div class="mb-3 row px-2">

        <div class='col-6'> Địa chỉ

            <input name="address" type="text" value="<?php echo e($user->address); ?>" class="form-control shadow-none border-primary">
        </div>

        <div class='col-6'> Quền

            <select name="role" class="form-select shadow-none border-primary">

                <option value="0" <?php echo e($user->role==0? "selected":""); ?>> Khách hàng</option>

                <option value="1" <?php echo e($user->role==1? "selected":""); ?>> Admin</option>

            </select>

        </div>

    </div>  

    <div class='mb-3 px-2'>

        <button type="submit" class="btn btn-primary py-2 px-5 border-0"> Lưu database</button>

    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/admin/user_edit.blade.php ENDPATH**/ ?>