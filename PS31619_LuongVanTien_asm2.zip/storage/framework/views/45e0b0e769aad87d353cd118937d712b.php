<?php $__env->startSection('title'); ?>
Product of <?php echo e($producer_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="list_product" class="my-2">
    <h4 class="bg-info p-2 h5 text-white">Product of <?php echo e($producer_name); ?></h4>
    <div id="data" class="d-flex flex-wrap text-center">
        <?php $__currentLoopData = $list_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="border border-primary rounded bg-info-subtle m-2 mt-0">
                    <h4 class="p-2"><a href="/productDetail/<?php echo e($product->id); ?>" class="text-decoration-none"><?php echo e($product->name); ?></a></h4>
                    <img src="<?php echo e($product->image); ?>" class="w-100" alt="Image of <?php echo e($product->name); ?>">
                    <p class="fs-5">Price: <del><?php echo e(number_format($product->price, 0, ",",".")); ?> VND</del></p>
                    <p class="fs-5 fw-bolder">Promotion: <?php echo e(number_format($product->price - $product->promotional_price, 0, ",",".")); ?> VND</p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="p-2">
        <?php echo e($list_product->onEachSide(5)->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/productInProducer.blade.php ENDPATH**/ ?>