<?php $__env->startSection('title'); ?> Thành viên <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="post" action="<?php echo e(url('/login')); ?>"

class = "m-auto col-6 border border-primary mt-5" > <?php echo csrf_field(); ?>

<?php if(Session::exists('message')): ?>

<h5 class="alert alert-info text-center"> <?php echo e(Session::get('message')); ?> </h5>

<?php endif; ?>

<div class="mb-3"> <h3 class="text-center"> Thành viên đăng nhập</h3> </div>

<div class="mb-3 px-3">

<label>Email</label>

<input type="text" name="email" class="form-control shadow-none p-2">

</div>

<div class="mb-3 px-3">

<label>Mật khẩu</label>

<input type="password" name="matkhau" class="form-control shadow-none p-2">

</div>

<div class="mb-3 px-3">

<button type="submit" name="btn" class="btn btn-primary">Đăng nhập</button>
<button type="button" class="btn btn-success"><a href="/register" style="text-decoration: none; color: white;">Đăng kí</a></button>
<button type="button" class="btn btn-warning"><a href="/forgot-password" style="text-decoration: none; color: #000;">Quên mật khẩu</a></button>

</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/login.blade.php ENDPATH**/ ?>