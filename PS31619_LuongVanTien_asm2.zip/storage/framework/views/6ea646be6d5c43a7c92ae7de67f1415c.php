<?php $__env->startSection('title'); ?> Giỏ hàng của bạn <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="container" style="padding-top: 100px; padding-bottom: 100px;">
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Đơn giá</th>
                    <th>Thành tiền</th>
                    <th>Hành động</th>
                    <th>Tổng tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total = $item['price'] * $item['quantity']; ?>
                <tr>
                    <td class=""><b><?php echo e($item['name']); ?></b></td>
                    <td>
                        <form action="/updatecart" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($item['id']); ?>">
                            <input type="number" name="quantity" value="<?php echo e($item['quantity']); ?>" class="form-control m-auto w-75 border-border-secondary shadow-none" onchange="this.form.submit()">
                        </form>
                    </td>
                    <td class=""><?php echo e(number_format($item['price'], 0, ',', '.')); ?> VNĐ</td>
                    <td class=""><?php echo e(number_format($item['totalprice'], 0, ',', '.')); ?> VNĐ</td>
                    <td class="">
                        <a href="/delcart/<?php echo e($item['id']); ?>" class="btn btn-danger btn-sm">Xóa</a>
                    </td>

                    <td class=""><?php echo e(number_format($total, 0, ',', '.')); ?> VNĐ</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2"></td>
                    <td>Tổng số lượng</td>
                    <td><?php echo e($totalquantity); ?></td>
                    <td>Tổng tiền cần thanh toán</td>
                    <td><?php echo e(number_format($totalprice, 0, ',', '.')); ?> VNĐ</td>
                </tr>
            </tfoot>

        </table>

    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/viewcart.blade.php ENDPATH**/ ?>