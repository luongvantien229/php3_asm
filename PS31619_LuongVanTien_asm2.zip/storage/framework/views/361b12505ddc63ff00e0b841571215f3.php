<?php $__env->startSection('title'); ?> Thêm nhà phân phối <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-dark text-center my-4">Thêm sản phẩm</h1>

<form action="<?php echo e(route('producer.store')); ?>" method="post"

class="m-auto col-10 border border-primary p-3 mt-3 shadow-lg fs-5"><?php echo csrf_field(); ?>

<div class='mb-3'>

<label> Tên nhà phân phối</label>

<input name="name" type="text" class="form-control border-primary shadow-none">

</div>

<div class='mb-3'> <label> Thứ tự</label>

<input name="order" type="number" class="form-control border-primary shadow-none" min="1">

</div>

<div class='mb-3'> <label> Ẩn hiện</label>

<input name="hidden" type="radio" value="0"> Ẩn

<input name="hidden" type="radio" value="1" checked> Hiện

</div>

<div class='mb-3'>

<button type="submit" class="btn btn-success py-2 px-5 border-0"> Lưu database</button>

</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/admin/producer_create.blade.php ENDPATH**/ ?>