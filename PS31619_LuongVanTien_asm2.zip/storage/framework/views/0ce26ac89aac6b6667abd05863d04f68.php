<?php $__env->startSection('title'); ?> Giỏ hàng của bạn <?php $__env->stopSection(); ?>

<?php $__env->startSection('noidungchinh'); ?>

<table class="table table-bordered align-middle border-primary m-2" id="tblgiohang">

    <caption class="fw-bolder text-center fs-4" align=" top">SẢN PHẨM BẠN ĐÃ CHỌN </caption>

    <tr>

        <thead class="text-center">

            <th>Tên sản phẩm</th>
            <th>Số lượng </th>

            <th>Đơn giá</th>
            <th>Thành tiền</th>
            <th>Xóa</th>

        </thead>

    </tr>

    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php var_dump($cart); ?>

    <tr>

      

        <td><input type='number' value="<?php echo e($c['quantity']); ?>" class='form-control m-auto w-75 border-border-secondary shadow-none'></td>

        <td class="text-end"> <?php echo e(number_format($c['price'] , 0, ',' , '.' )); ?> VNĐ</td>

       

        <td class="text-center">

            <a href="/xoasptronggio/<?php echo e($c['id']); ?>">Xóa</a>

        </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <th colspan="5" class='text-center'>

         

        </th>

    </tr>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/viewcard.blade.php ENDPATH**/ ?>