<!-- viet mật khẩu mới -->
<p>Chào bạn,</p>
<p>Chúng tôi đã nhận được yêu cầu đặt lại mật khẩu của bạn. Đây là mật khẩu mới của bạn:</p>
<p><strong><?php echo e($password); ?></strong></p>
<p>Vui lòng đăng nhập và thay đổi mật khẩu ngay sau khi đăng nhập.</p>
<p>Trân trọng,</p>
<p>Admin</p>
```
<?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/emails/password_reset.blade.php ENDPATH**/ ?>