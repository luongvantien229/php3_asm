<?php $__env->startSection('title'); ?> Đăng ký thành viên <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="alert alert-info text-center">

<?php if(Session::exists('message')): ?>

<h4><?php echo e(Session::get('message')); ?></h4> <hr>

<?php endif; ?>

<a href="/">Về trang chủ</a>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/thanks.blade.php ENDPATH**/ ?>