<div class="row mt-5">
    <h1 class="mb-3">Sản phẩm bán chạy</h1>
    <?php $__currentLoopData = $hot_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-6 mb-4">
        <div class="card" style="padding: 10px;">
            <img src="<?php echo e($product->image); ?>" class="card-img-top" alt="Product">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                <p class="card-text">Giá: <del><?php echo e(number_format($product->price, 0, ',', '.')); ?> VND</del></p>
                <p class="card-text">Giá khuyễn mãi: <?php echo e(number_format($product->price - $product->promotional_price, 0, ',', '.')); ?> VND</p>
                <a href="/productDetail/<?php echo e($product->id); ?>" class="btn btn-primary">Mua ngay</a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/hot_product.blade.php ENDPATH**/ ?>