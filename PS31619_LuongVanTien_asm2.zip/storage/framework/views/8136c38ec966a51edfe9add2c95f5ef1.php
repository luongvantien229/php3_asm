<?php $__env->startSection('title'); ?> Danh sách tài khoản <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session()->has('message')): ?>

<div class="alert alert-danger p-3 mx-auto my-3 col-10 fs-5 text-center">

    <?php echo session('message'); ?>


</div>

<?php endif; ?>

<table class="table table-bordered m-auto" id="dssanpham">

    <div class="d-flex flex-1 justify-content-between bg-info-subtle border border-primary mt-5">
        <h2 class="p-2 fs-4 mb-0">Danh sách tài khoản</h2>
        <a href="/admin/user/create" class="btn text-primary" style="font-size: 20px;">Thêm tài khoản</a>
    </div>

    <tr>
        <th>Tên sản phẩm </th>
        <th>Email </th>
        <th>Mật khẩu</th>

        <th>Địa chỉ</th>
        <th>Điện thoại</th>
        <th>Sửa Xóa</th>

    </tr>

    <?php $__currentLoopData = $user_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <td><?php echo e($user->name); ?></td>

    <td><b><?php echo e($user->email); ?></b>

    </td>

    <td> <?php echo e($user->password); ?></td>


    </td>

    <td> <?php echo e($user-> address); ?></td>

    <td> <?php echo e($user->number); ?>


    </td>

    <td> <a class="btn btn-primary btn-sm" href="<?php echo e(route('user.edit', $user->id)); ?>">Sửa</a>
        <form class="d-inline" action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">

            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>

            <button type='submit' onclick="return confirm('Bạn muốn xóa??')" class="btn btn-danger btn-sm">

                Xóa

            </button>

        </form>
    </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td colspan="6"> <?php echo e($user_arr->links()); ?> </div>
        </td>
    </tr>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/admin/user_list.blade.php ENDPATH**/ ?>