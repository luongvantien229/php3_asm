<?php $__env->startSection('title'); ?> Đăng ký thành viên <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="post" action="<?php echo e(url('/register')); ?>"

class="m-auto col-10 border border-2 border-primary rounded mt-3 shadow-lg"> <?php echo csrf_field(); ?>

<h3 class="text-center mt-2">ĐĂNG KÝ THÀNH VIÊN</h3>

<div class="m-3 mt-0 row">

<div class="col-6"> Email

<input name="email" value="<?php echo e(old('email')); ?>" type="text"

class="form-control border-primary shadow-none p-2">

<b class="text-danger"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </b>

</div>

<div class="col-6">Họ tên

<input name="name" value="<?php echo e(old('name')); ?>" type="text"

class="form-control border-primary shadow-none p-2">

<b class="text-danger"> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </b>

</div>

</div>

<div class="m-3 row">

<div class="col-6"> Mật khẩu

<input name="password1" value="<?php echo e(old('password1')); ?>" type="password"

class="form-control border-primary shadow-none p-2">

<b class="text-danger"> <?php $__errorArgs = ['password1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </b>

</div>

<div class="col-6"> Nhập lại mật khẩu

<input name="password2" value="<?php echo e(old('password2')); ?>" type="password"

class="form-control border-primary shadow-none p-2">

<b class="text-danger"> <?php $__errorArgs = ['password2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </b>

</div>

</div>

<div class="m-3 row">

<div class="col-6"> Địa chỉ

<input name="address" value="<?php echo e(old('dia_chi')); ?>" type="text"

class="form-control border-primary shadow-none p-2">

<b class="text-danger"> <?php $__errorArgs = ['dia_chi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </b>

</div>

<div class="col-6"> Điện thoại

<input name="number" value="<?php echo e(old('dien_thoai')); ?>" type="text"

class="form-control border-primary shadow-none p-2">

<b class="text-danger"> <?php $__errorArgs = ['dien_thoai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </b>

</div>

</div>

<div class="m-3 row">

<div><button class="btn btn-primary py-2 px-5"type="submit">Đăng ký</button>
<button class="btn btn-success py-2 px-5" type="button"><a href="/login" style="text-decoration: none; color: white;">Đăng nhập</a></button>
<button class="btn btn-warning py-2 px-5" type="button"><a href="/forgot-password" style="text-decoration: none; color: #000;">Quên mật khẩu</a></button>
</div>


</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/register.blade.php ENDPATH**/ ?>