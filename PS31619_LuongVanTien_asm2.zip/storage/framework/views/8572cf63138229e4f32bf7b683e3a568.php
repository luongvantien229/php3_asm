<?php $__env->startSection('title'); ?>
    <?php echo e($product->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="productDetail" class="my-2">
        <h4 class="bg-info p-2 fs-4 text-white">Chi tiết sản phẩm <?php echo e($product->name); ?></h4>
        <div id="data" class="d-flex row">
            <div id="left" class="col-md-6">
                <img src="<?php echo e($product->image); ?>" class="w-100" alt="Image of <?php echo e($product->name); ?>">
            </div>
            <div id="right" class="col-md-6 fs-5">
                <h3><?php echo e($product->name); ?></h3>
                <p>Giá: <del><?php echo e(number_format($product->price, 0, ",",".")); ?> VND</del></p>
                <p>Giá khuyến mãi: <?php echo e(number_format($product->price - $product->promotional_price, 0, ",",".")); ?> VND</p>
                <p>Màu: <?php echo e($product->color); ?></p>
                <p>Cân nặng: <?php echo e($product->weight); ?></p>
                <p>Tính chất: <?php echo e($product->nature); ?></p>
                <!-- <p><input type="number" value="1"></p> -->
                <a href="/addcart/<?php echo e($product->id); ?>" class="btn btn-primary">Thêm vào giỏ hàng</a>
            </div>
        </div>
    </div>
    <?php echo $__env->make('comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('product_same_id', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/productDetail.blade.php ENDPATH**/ ?>