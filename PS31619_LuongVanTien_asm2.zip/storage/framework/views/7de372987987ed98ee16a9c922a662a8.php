<?php $__env->startSection('title'); ?> Danh sách sản phẩm <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session()->has('message')): ?>

<div class="alert alert-danger p-3 mx-auto my-3 col-10 fs-5 text-center">

<?php echo session('message'); ?>


</div>

<?php endif; ?>

<table class="table table-bordered m-auto" id="dssanpham">

<div class="d-flex flex-1 justify-content-between bg-info-subtle border border-primary mt-5">
    <h2 class="p-2 fs-4 mb-0">Danh sách sản phẩm</h2>
    <a href="/admin/product/create" class="btn text-primary" style="font-size: 20px;">Thêm sản phẩm</a>
</div>

<tr><th>Hình</th> <th>Tên sản phẩm </th> <th>Lượt xem </th> <th>Giá</th>

<th>Ngày</th> <th>Trạng thái</th> <th>Sửa Xóa</th>

</tr>

<?php $__currentLoopData = $product_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr><td><img src="<?php echo e($product->image); ?>" width="120" height="80"></td>
<td><?php echo e($product->name); ?></td>

<td><b><?php echo e($product->ten_sp); ?></b> <br> Lượt xem: <?php echo e($product->view); ?>


</td>

<td>Giá:<?php echo e(number_format($product->price    ,0,',', '.')); ?> <br>

KM : <?php echo e(number_format($product->promotional_price,0,',', '.')); ?>


</td>

<td> <?php echo e(date('d/m/ Y',strtotime($product->date))); ?></td>

<td> Ẩn hiện: <?php echo e(($product->hidden==0)? "Đang ẩn":"Đang hiện"); ?> <br>

Nổi bật: <?php echo e(($product->hot==0)? "Bình thường":"Nổi bật"); ?>


</td>

<td> <a class="btn btn-primary btn-sm" href="<?php echo e(route('product.edit', $product->id)); ?>">Sửa</a> <form class="d-inline" action="<?php echo e(route('product.destroy', $product->id)); ?>" method="POST">

<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>

<button type='submit' onclick="return confirm('Bạn muốn xóa??')" class="btn btn-danger btn-sm">

Xóa

</button>

</form> </td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<tr> <td colspan="6"> <?php echo e($product_arr->links()); ?> </div> </td> </tr>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/admin/product_list.blade.php ENDPATH**/ ?>