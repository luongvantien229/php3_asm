<?php $__env->startSection('title'); ?> Danh sách nhà phân phối <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-1 justify-content-between bg-info-subtle border border-primary mt-5">
    <h2 class="p-2 fs-4 mb-0">Danh sách nhà phân phối</h2>
    <a href="/admin/producer/create" class="btn text-primary" style="font-size: 20px;">Thêm loại sản phẩm</a>
</div>


<?php if(session()->has('message')): ?>

<div class="alert alert-danger p-3 mx-auto my-3 col-10 fs-5 text-center">

    <?php echo session('message'); ?>


</div>

<?php endif; ?>

<table class="table table-bordered border border-primary">

    <tr class="text-center">

        <th>id</th>
        <th>Tên loại</th>
        <th>Thứ tự</th>
        <th>Ẩn hiện </th>
        <th>Hành động</th>

    </tr>

    <?php $__currentLoopData = $producer_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr class="text-center">

        <td><?php echo e($producer->id); ?></td>

        <td><?php echo e($producer->name); ?></td>

        <td><?php echo e($producer->order); ?></td>

        <td><?php echo e($producer->hidden==1?"Đang hiện":"Đang ẩn"); ?></td>

        <td class="text-center"> <a href="<?php echo e(url('admin/producer/'.$producer->id.'/edit')); ?>" class="btn btn-primary btn-sm mx-1">

                Chỉnh

            </a>
            <form class="d-inline" action="<?php echo e(route('producer.destroy', $producer->id)); ?>" method="POST">

                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>

                <button type='submit' onclick="return confirm('Bạn muốn xóa??')" class="btn btn-danger btn-sm ms-1">Xóa</button>

            </form>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<div class="text-center p-2"><?php echo e($producer_arr->links()); ?></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/admin/producer_list.blade.php ENDPATH**/ ?>