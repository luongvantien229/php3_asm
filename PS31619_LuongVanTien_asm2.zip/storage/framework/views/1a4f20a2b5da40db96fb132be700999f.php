<?php $__env->startSection('title'); ?> Trang download <?php $__env->stopSection(); ?>

<?php $__env->startSection('noidungchinh'); ?>

<h3 class="alert alert-info p-3 text-center">

Đây là trang download, chỉ hiện cho các user đã đăng nhập

</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/download.blade.php ENDPATH**/ ?>