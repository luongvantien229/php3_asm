Chào Admin! Có người một khách hàng liên hệ từ website nè: <hr>
<p>Họ tên khách hàng <?php echo e($hoten); ?></p>
<p>Nội dung khách liên hệ : <br> 
    <?php echo nl2br($noidung); ?>

<p></p><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/viewContactMail.blade.php ENDPATH**/ ?>