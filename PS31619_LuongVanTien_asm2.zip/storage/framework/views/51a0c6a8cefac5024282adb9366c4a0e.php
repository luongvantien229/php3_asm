<?php $__env->startSection('title'); ?>
Thông báo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session()->has('notification')): ?>
    <div class="alert alert-info p-5 shadow-lg border-2 border border-info m-5 fs-3 text-center">
        <h1>Thông báo</h1>
        <p></p><?php echo e(Session::get('notification')); ?></p>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/notification.blade.php ENDPATH**/ ?>