<?php $__env->startSection('title'); ?> Thêm tài khoản <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form class="mt-5" id="frm" method="post" action="<?php echo e(route('user.store')); ?>" class="m-auto w-10 border border-primary"> <?php echo csrf_field(); ?>

    <h4 class="m-0 bg-warning p-2 fs-5"> THÊM TÀI KHOẢN</h4>

    <div class="mb-3 row px-2">

        <div class='col-6'> Tên tài khoản

            <input name="name" type="text" class="form-control shadow-none border-primary">

        </div>

        <div class='col-6'> Email

            <input name="email" type="email" class="form-control shadow-none border-primary">
        </div>

    </div>

    <div class="mb-3 row px-2">

        <div class='col-6'> Mật khẩu

            <input name="password" type="password" class="form-control shadow-none border-primary">
        </div>

        <div class='col-6'> Số điện thoại

            <input name="phone" type="text" class="form-control shadow-none border-primary">
        </div>

    </div>

    <div class="mb-3 row px-2">

        <div class='col-6'> Địa chỉ

            <input name="address" type="text" class="form-control shadow-none border-primary">

        </div>

        <div class='col-6'> Quyền

            <select name="role" class="form-select shadow-none border-primary">

                <option value="0"> Khách hàng</option>

                <option value="1"> Admin</option>

            </select>
        </div>
    </div>
    

   

   

    <div class='mb-3 px-2'>

        <button type="submit" class="btn btn-primary py-2 px-5 border-0"> Lưu database</button>

    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/admin/user_create.blade.php ENDPATH**/ ?>