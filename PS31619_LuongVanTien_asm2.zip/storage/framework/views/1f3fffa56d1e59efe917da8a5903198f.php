<?php $__env->startSection('title'); ?> Đăng ký thành viên <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="post" action="/change-password/<?php echo e(Auth::user()->id); ?>"

class = "m-auto col-6 border border-primary mt-5" > <?php echo csrf_field(); ?>

<?php if(Session::exists('message')): ?>

<h5 class="alert alert-info text-center"> <?php echo e(Session::get('message')); ?> </h5>

<?php endif; ?>

<div class="mb-3"> <h3 class="text-center"> Thay đổi mật khẩu</h3> </div>

<div class="mb-3 px-3">

<label>Email</label>

<input type="text" name="email" class="form-control shadow-none p-2">

</div>

<div class="mb-3 px-3">

<label>Mật khẩu cũ</label>

<input type="password" name="password" class="form-control shadow-none p-2">

</div>
<div class="mb-3 px-3">

<label>Mật khẩu mới</label>

<input type="password" name="password1" class="form-control shadow-none p-2">

</div>


<div class="mb-3 px-3">

<button type="submit" class="btn btn-primary">Thay đổi</button>

</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/changePassword.blade.php ENDPATH**/ ?>