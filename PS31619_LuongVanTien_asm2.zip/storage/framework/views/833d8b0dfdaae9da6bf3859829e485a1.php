<?php $__env->startSection('title'); ?> Quên mật khẩu <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- nhap email gửi gmail về -->
<form method="post" action="<?php echo e(url('/forgot-password')); ?>"
class="m-auto col-6 border border-primary mt-5"> <?php echo csrf_field(); ?>
<input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>">
<div class="mb-3 px-3">
<label>Email</label>
<input type="text" name="email" class="form-control shadow-none p-2">
</div>
<div class="mb-3 px-3">
<button type="submit" name="btn" class="btn btn-primary">Gửi email</button>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/forgotPassword.blade.php ENDPATH**/ ?>