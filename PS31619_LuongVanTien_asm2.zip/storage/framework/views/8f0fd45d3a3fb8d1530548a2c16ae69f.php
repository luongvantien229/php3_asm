<?php if(Auth::check()): ?>
<h2 class="bg-success mt-3 p-2 fs-5 text-white"> Bình luận sản phẩm</h2>

<form class="border border-success p-3 m-2" method="post" action="/comment_save">

<p>

<textarea class="form-control shadow-none fs-5"

name="content" rows="4" placeholder="Mời nhập bình luận"></textarea>

</p>

<p class="text-end"> <?php echo csrf_field(); ?>

<input type="hidden" name="id_product" value="<?php echo e($product->id); ?>">

<button class="btn btn-success "> Gửi bình luận</button>

<p>

</form>


<div id="list_binh_luan">

<?php $__currentLoopData = $comment_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="border border-success m-2 p-2">

<p class="d-flex justify-content-between">


<b><?php echo e($comment->User->name); ?></b>
<span><?php echo e(gmdate('d/m/Y H:m:s', strtotime($comment->date)+3600*7)); ?></span>

</p>

<p><?php echo e($comment->content); ?></p>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/code/php3_asm/resources/views/comment.blade.php ENDPATH**/ ?>